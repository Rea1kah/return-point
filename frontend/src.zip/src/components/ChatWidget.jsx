import { useState, useEffect, useRef } from 'react';
import { FaCommentDots, FaTimes, FaPaperPlane, FaArrowLeft } from 'react-icons/fa';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import '../styles/ChatWidget.css';

export default function ChatWidget() {
  const { user } = useAuth();
  const { isOpen, toggleChat, activeChat, setActiveChat } = useChat(); 
  
  const [messageInput, setMessageInput] = useState('');
  const messagesEndRef = useRef(null);

  const [conversations] = useState([
    { id: 1, name: 'Budi Santoso', lastMsg: 'Apakah dompetnya masih ada?', time: '10:30', unread: 2, avatar: 'B' },
    { id: 2, name: 'Siti Aminah', lastMsg: 'Terima kasih banyak kak!', time: 'Yesterday', unread: 0, avatar: 'S' },
  ]);

  const [messages, setMessages] = useState([
    { id: 1, sender: 'other', text: 'Halo, saya melihat laporan Anda.', time: '10:28' },
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && activeChat) {
      scrollToBottom();
    }
  }, [messages, isOpen, activeChat]);

  if (!user) return null;

  const handleSend = (e) => {
    e.preventDefault();
    if (!messageInput.trim()) return;

    const newMsg = {
      id: Date.now(),
      sender: 'self',
      text: messageInput,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages([...messages, newMsg]);
    setMessageInput('');

    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        sender: 'other',
        text: 'Baik, terima kasih infonya.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    }, 2000);
  };

  return (
    <>
      <button className="chat-widget-toggle" onClick={toggleChat}>
        {isOpen ? <FaTimes className="chat-icon-size" /> : <FaCommentDots className="chat-icon-size" />}
        {!isOpen && conversations[0].unread > 0 && (
          <span className="chat-badge">{conversations[0].unread}</span>
        )}
      </button>

      {isOpen && (
        <div className="chat-window">
          <div className="chat-header">
            <div className="chat-header-info">
              {activeChat ? (
                <>
                  <button onClick={() => setActiveChat(null)} className="btn-close-chat" style={{marginRight: '8px'}}>
                    <FaArrowLeft />
                  </button>
                  <div className="header-avatar">{activeChat.avatar}</div>
                  <div className="header-text">
                    <h3>{activeChat.name}</h3>
                    <p>Online</p>
                  </div>
                </>
              ) : (
                <div className="header-text">
                  <h3>Pesan</h3>
                  <p>Percakapan Terbaru</p>
                </div>
              )}
            </div>
          </div>

          <div className="chat-body">
            {activeChat ? (
              <>
                {messages.map((msg) => (
                  <div key={msg.id} className={`message-wrapper ${msg.sender}`}>
                    <div className="message-bubble">
                      {msg.text}
                    </div>
                    <span className="message-time">{msg.time}</span>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </>
            ) : (
              <div className="chat-list">
                {conversations.map(chat => (
                  <div 
                    key={chat.id} 
                    className="chat-list-item"
                    onClick={() => setActiveChat(chat)}
                    style={{
                      padding: '12px', borderBottom: '1px solid #f1f5f9', 
                      cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '12px',
                      transition: 'background 0.2s'
                    }}
                    onMouseOver={(e) => e.currentTarget.style.background = '#f8fafc'}
                    onMouseOut={(e) => e.currentTarget.style.background = 'transparent'}
                  >
                    <div className="header-avatar" style={{background: '#cbd5e1', color: '#334155'}}>{chat.avatar}</div>
                    <div style={{flex: 1}}>
                      <div style={{display:'flex', justifyContent:'space-between'}}>
                        <h4 style={{fontSize:'0.95rem', margin:0, color:'#1e293b'}}>{chat.name}</h4>
                        <span style={{fontSize:'0.75rem', color:'#94a3b8'}}>{chat.time}</span>
                      </div>
                      <p style={{fontSize:'0.85rem', margin:'4px 0 0', color:'#64748b', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', maxWidth:'180px'}}>
                        {chat.lastMsg}
                      </p>
                    </div>
                    {chat.unread > 0 && (
                      <span style={{background:'#ef4444', width:'8px', height:'8px', borderRadius:'50%'}}></span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {activeChat && (
            <div className="chat-footer">
              <form onSubmit={handleSend} className="chat-input-form">
                <input
                  type="text"
                  className="chat-input"
                  placeholder="Tulis pesan..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                />
                <button type="submit" className="btn-send" disabled={!messageInput.trim()}>
                  <FaPaperPlane />
                </button>
              </form>
            </div>
          )}
        </div>
      )}
    </>
  );
}