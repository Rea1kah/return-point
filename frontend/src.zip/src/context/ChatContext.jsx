import { createContext, useContext, useState, useCallback } from 'react';

const ChatContext = createContext(null);

export const ChatProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeChat, setActiveChat] = useState(null);

  const toggleChat = useCallback(() => setIsOpen(prev => !prev), []);
  
  const openChatWith = useCallback((targetUser) => {
    setIsOpen(true);
    setActiveChat({
      id: targetUser.id || Date.now(),
      name: targetUser.name || targetUser.reporter || 'Pengguna',
      avatar: (targetUser.name || targetUser.reporter || 'U').charAt(0).toUpperCase(),
      status: 'Online',
    });
  }, []);

  const closeChat = useCallback(() => setIsOpen(false), []);

  return (
    <ChatContext.Provider value={{ 
      isOpen, 
      setIsOpen, 
      activeChat, 
      setActiveChat, 
      toggleChat, 
      openChatWith, 
      closeChat 
    }}>
      {children}
    </ChatContext.Provider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};